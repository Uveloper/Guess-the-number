/**
 * @author Uvoh T. Otite
 * @date 11/06/2016
 */

package com.uvohicious.guessthenumber2;

import android.content.Context;
import android.media.AudioManager;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Random;
import android.content.SharedPreferences;
import android.media.MediaPlayer;

public class MainActivity extends AppCompatActivity {

    int numberOfGuess = 0;
    int secretNumber = -1;
    int guessNumber = -1;
    boolean range_1000 = false;
    boolean range_100 = false;
    private EditText enterText;
    private TextView OutcomeText;
    private Button range1000;
    private Button range100;
    private Button startGame;
    private Button reset;
    private TextView editTextScore;
    private ImageView imageView;
    private int thePlayerScore = 0;
    private int theComputerScore = 0;
    private String score = "";
    private SharedPreferences.Editor editor;
    private MediaPlayer pianoMusic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        range100 = (Button)findViewById(R.id.btnRange100);
        range1000 = (Button)findViewById(R.id.btnRange1000);
        enterText = (EditText)findViewById(R.id.editTextEnter);
        OutcomeText = (TextView)findViewById(R.id.editTextOut);
        startGame = (Button)findViewById(R.id.btnStartNew);
        imageView = (ImageView)findViewById(R.id.imageView);
        reset = (Button)findViewById(R.id.btnReset);
        editTextScore = (TextView)findViewById(R.id.textViewScore);
        pianoMusic = new MediaPlayer();//.create(this, R.raw.piano);
        try {
            pianoMusic.setDataSource(this, Uri.parse("http://www.downloadfreesound.com/wp-content/uploads/2013/07/Battle_Pirate_Theme_Music_1.mp3"));
            pianoMusic.setAudioStreamType(AudioManager.STREAM_MUSIC);
            pianoMusic.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        pianoMusic.setLooping(true);
        enterText.setEnabled(false);
        OutcomeText.setEnabled(false);

        /* if a preferences file named PLAYER_SCORE already exists, get it
         otherwise, create one (when required by the associate editor)
         data stored in this file are for the use of this app only */
        SharedPreferences preferences = getSharedPreferences("PLAYER_SCORE", Context.MODE_PRIVATE);
        // create an editor to read and write from/to the preferences file
        editor = preferences.edit();

        // if the preferences file contains a key 'playerScore', retrieve the associated value
        // and use it to set the player score variable
        if (preferences.contains(("playerScore"))){
            thePlayerScore = preferences.getInt("playerScore", 0);
        }

        if (preferences.contains(("computerScore"))){
            theComputerScore = preferences.getInt("computerScore", 0);
        }

        score = thePlayerScore + " / " + theComputerScore;
        editTextScore.setText(score);

        // Listeners for the range100 button
        range100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                range1000.setEnabled(false);
                Toast.makeText(getApplicationContext(), "Range 0 - 100", Toast.LENGTH_SHORT).show();
                range_100 = true;
                enterText.setEnabled(true);
                OutcomeText.setEnabled(true);
                playMusic(v);

                start();
            }
        });

        // Listeners for the reset button
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                thePlayerScore = 0;
                theComputerScore = 0;
                score = "0 / 0";
                editor.putInt("playerScore", thePlayerScore);
                editor.putInt("computerScore", theComputerScore);
                editor.commit(); // apply() can be used
                set();

            }
        });

        // Listeners for the start button
        startGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set();
            }
        });

        // Listeners for the range1000 button
        range1000.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                range100.setEnabled(false);
                range_1000 = true;
                enterText.setEnabled(true);
                OutcomeText.setEnabled(true);
                Toast.makeText(getApplicationContext(), "Range 0 - 1000", Toast.LENGTH_SHORT).show();
                playMusic(v);
                start();
            }
        });

        // listener for the enterText text field

        enterText.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {


                    // Perform action on key press
                    try {
                        guessNumber = Integer.parseInt(enterText.getText().toString());
                        if (validateGuess(guessNumber)) {
                            displayResults(guessNumber);
                            InputMethodManager imm = (InputMethodManager)getApplicationContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                            imm.hideSoftInputFromWindow(enterText.getApplicationWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

                        }
                    }catch(Exception e){
                        System.out.println("Error " + e.getMessage());
                        OutcomeText.setText("Invalid value: " + e.getMessage());
                    }
                    return true;

                }
                return false;
            }
        });
    }

    /**
     * Used to set the default values to start or reset the game
     */
    public  void set(){
        range1000.setEnabled(true);
        range100.setEnabled(true);
        enterText.setEnabled(false);
        enterText.setText("");
        OutcomeText.setEnabled(false);
        OutcomeText.setText("");
        range_100 = false;
        range_1000 = false;
    }

    /**
     * Used to start the game
     */
    public void start(){

        Random rand = new Random();

        // used to select a range
        if(range_1000){
            numberOfGuess = 10;
            secretNumber = rand.nextInt(1001);
            OutcomeText.setText(R.string.tenGuess);

        }
        else{
            numberOfGuess = 7;
            secretNumber = rand.nextInt(101);
            OutcomeText.setText(R.string.sevenGuess);
        }

        imageView.setImageResource(R.mipmap.gon);
    }

    /**
     * Used to validate the entered guessed number
     * @param guess is the guessed number
     * @return true or false
     */
    public boolean validateGuess(int guess){

        boolean validRange = false;

        //try block used to reject non-numeric entries
        try{
            System.out.println("Your Guess was " + guess);

            // used to validate the guess to ensure it is within the range
            if(range_1000 && (guess > 1000) || (guess < 0)){
                OutcomeText.setText(R.string.invalid1000);
            }
            else if((range_100) && (guess > 100 || guess < 0)){
                OutcomeText.setText(R.string.invalid100);
            }
            else{
                validRange = true;
            }

        }catch(Exception e){
            System.out.println("Error has occurred " + e.getMessage());
        }

        return validRange;
    }

    /**
     * Used to display the outcome to the player
     * @param guess the guessed number
     */
    public void displayResults(int guess){
        String result ="";

        // reduce the count by 1
        numberOfGuess = numberOfGuess - 1;
        String message;

        System.out.println("Remaining guess(es): " + numberOfGuess);

        if(guess > secretNumber){
            result = "LOWER";
            message = "Remaining guess(es): " + numberOfGuess + ". Go--> " + result;
            OutcomeText.setText(message);
        }
        else if(guess < secretNumber){
            result = "HIGHER";
            message = "Remaining guess(es): " + numberOfGuess + ". Go--> " + result;
            OutcomeText.setText(message);
        }
        else if(guess == secretNumber){
            result = "CORRECT";
            message = "Remaining guess(es): " + numberOfGuess + ". Go--> " + result;
            OutcomeText.setText(message);
        }
        else{
            System.out.println("Invalid Guess");
        }

        //clear the text field after the enter button pressed
        enterText.setText("");

        //checks used to control the game
        if(!(numberOfGuess == 0) && result.equals("CORRECT")){
            message = "You win!. With " + numberOfGuess + " guess(es) remaining";
            OutcomeText.setText(message);
            range1000.setEnabled(false);
            range100.setEnabled(false);
            enterText.setEnabled(false);
            imageView.setImageResource(R.mipmap.ywin);
            thePlayerScore += 1;
            score = thePlayerScore + " / " + theComputerScore;
            editTextScore.setText(score);
            pauseMusic();

            // save scores to the preferences file immediately (Places in the Win, or Lose areas)
            editor.putInt("playerScore", thePlayerScore); // thePlayerScore += 1; for win
            editor.commit();

        }
        else if(numberOfGuess == 0 && result.equals("CORRECT")){
            message = "You win!. With "+ numberOfGuess + " guess(es) remaining";
            OutcomeText.setText(message);
            range1000.setEnabled(false);
            range100.setEnabled(false);
            enterText.setEnabled(false);
            imageView.setImageResource(R.mipmap.ywin);
            thePlayerScore += 1;
            score = thePlayerScore + " / " + theComputerScore;
            editTextScore.setText(score);
            pauseMusic();

            // save scores to the preferences file immediately (Places in the Win, or Lose areas)
            editor.putInt("playerScore", thePlayerScore); // thePlayerScore += 1; for win
            editor.commit();

        }
        else if(numberOfGuess == 0 && !(result.equals("CORRECT"))){
            message = "Out of guesses";
            OutcomeText.setText(message);
            range1000.setEnabled(false);
            range100.setEnabled(false);
            enterText.setEnabled(false);
            imageView.setImageResource(R.mipmap.gover);
            theComputerScore += 1;
            score = thePlayerScore + " / " + theComputerScore;
            editTextScore.setText(score);
            pauseMusic();

            // save scores to the preferences file immediately (Places in the Win, or Lose areas)
            editor.putInt("computerScore", theComputerScore); // theComputerScore += 1; for lose
            editor.commit();
        }
    }

    /**
     *  called when the play button defined in activity_main.xml is clicked
     *  start (or resume) the music playback
     * @param v the View which triggered the method call: should refer to button_play
     */
    public void playMusic (View v) {
        pianoMusic.start();
    }

    /**
     *  called when the pause button defined in activity_main.xml is clicked
     *  pause the music playback
     */
    public void pauseMusic() {
        if(pianoMusic.isPlaying())
            pianoMusic.pause();
    }

    /**
     * good practice: release allocated resources when they are no longer of use
     */
    @Override
    protected void onPause() {
        super.onPause();
        pianoMusic.release();
    }
}
